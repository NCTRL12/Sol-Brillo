package com.solbrillo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs

class FloatingService : Service() {
    companion object { @Volatile var running = false }
    private lateinit var wm: WindowManager
    private lateinit var sun: ImageView
    private lateinit var sunParams: WindowManager.LayoutParams
    private var menu: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun type() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sol", "Sol flotante", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "sol").setContentTitle("Sol Brillo activo").setSmallIcon(R.drawable.sun).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sun = ImageView(this).apply { setImageResource(R.drawable.sun); alpha = 0.6f }
        sunParams = WindowManager.LayoutParams(dp(56), dp(56), type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(200) }
        wm.addView(sun, sunParams)

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        sun.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = sunParams.x; sy = sunParams.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    sunParams.x = sx + dx.toInt(); sunParams.y = sy + dy.toInt()
                    wm.updateViewLayout(sun, sunParams)
                }
                MotionEvent.ACTION_UP -> if (!moved) toggleMenu()
            }
            true
        }
    }

    private fun toggleMenu() {
        menu?.let { wm.removeView(it); menu = null; return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply { setColor(0xEEFFFFFF.toInt()); cornerRadius = dp(16).toFloat() }
        }
        val label = TextView(this).apply { textSize = 15f; setTextColor(0xFF333333.toInt()) }
        val current = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 }
        label.text = "☀ Brillo: ${current * 100 / 255}%"
        val bar = SeekBar(this).apply {
            max = 255; progress = current
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser || !Settings.System.canWrite(this@FloatingService)) return
                    val v = p.coerceAtLeast(1)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
                    label.text = "☀ Brillo: ${v * 100 / 255}%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(label); box.addView(bar, LinearLayout.LayoutParams(dp(220), dp(40)))
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = sunParams.x; y = sunParams.y + dp(64) }
        box.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) toggleMenu(); false }
        wm.addView(box, p); menu = box
    }

    override fun onDestroy() {
        menu?.let { wm.removeView(it) }
        wm.removeView(sun)
        running = false
        super.onDestroy()
    }
}
