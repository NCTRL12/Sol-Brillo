package com.solbrillo

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var percent: TextView
    private lateinit var sunImg: ImageView
    private lateinit var bar: SeekBar
    private lateinit var toggle: Switch
    private lateinit var permBox: LinearLayout
    private val amber = Color.parseColor("#FFB300")
    private val text = Color.parseColor("#FFF8E1")
    private val soft = Color.parseColor("#BFA98A")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18))
        background = GradientDrawable().apply { setColor(Color.parseColor("#22FFFFFF")); cornerRadius = dp(24).toFloat()
            setStroke(dp(1), Color.parseColor("#33FFFFFF")) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
    }
    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        window.statusBarColor = Color.parseColor("#1A1026")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(40), dp(24), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#1A1026"), Color.parseColor("#3D1F2B"), Color.parseColor("#7A3B1F")))
        }
        root.addView(label("Sol Brillo", 30f, text, true))
        root.addView(label("Controla la luz de tu pantalla", 15f, soft))

        // Hero: sol + porcentaje
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) } }
        sunImg = ImageView(this).apply { setImageResource(R.drawable.sun); layoutParams = LinearLayout.LayoutParams(dp(150), dp(150)) }
        percent = label("--%", 56f, text, true).apply { gravity = Gravity.CENTER }
        hero.addView(sunImg); hero.addView(percent); hero.addView(label("nivel de brillo", 14f, soft).apply { gravity = Gravity.CENTER })
        root.addView(hero)

        // Slider
        val c1 = card()
        c1.addView(label("Brillo", 17f, text, true))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(label("🌙", 20f, text))
        bar = SeekBar(this).apply { max = 255; layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            progressTintList = android.content.res.ColorStateList.valueOf(amber)
            thumbTintList = android.content.res.ColorStateList.valueOf(amber)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) setBrightness(p) ; showLevel(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }) }
        row.addView(bar); row.addView(label("☀", 22f, amber))
        c1.addView(row)
        val presets = LinearLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) } }
        listOf("10%" to 25, "50%" to 128, "100%" to 255).forEach { (t, v) ->
            presets.addView(Button(this).apply { text = t; setTextColor(text); isAllCaps = false
                background = GradientDrawable().apply { setColor(Color.parseColor("#33FFB300")); cornerRadius = dp(14).toFloat() }
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) }
                setOnClickListener { setBrightness(v); bar.progress = v } })
        }
        c1.addView(presets)
        root.addView(c1)

        // Toggle botón flotante
        val c2 = card()
        val trow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        tcol.addView(label("Botón flotante", 17f, text, true))
        tcol.addView(label("Sol transparente sobre otras apps", 13f, soft))
        toggle = Switch(this).apply {
            thumbTintList = android.content.res.ColorStateList.valueOf(amber)
            setOnCheckedChangeListener { _, on -> setFloating(on) } }
        trow.addView(tcol); trow.addView(toggle)
        c2.addView(trow)
        root.addView(c2)

        // Permisos
        permBox = card()
        root.addView(permBox)

        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val b = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 }
        bar.progress = b; showLevel(b)
        toggle.setOnCheckedChangeListener(null); toggle.isChecked = FloatingService.running
        toggle.setOnCheckedChangeListener { _, on -> setFloating(on) }
        permBox.removeAllViews()
        val needWrite = !Settings.System.canWrite(this); val needOverlay = !Settings.canDrawOverlays(this)
        permBox.visibility = if (needWrite || needOverlay) View.VISIBLE else View.GONE
        if (needWrite || needOverlay) permBox.addView(label("Permisos necesarios", 17f, text, true))
        if (needWrite) permBox.addView(permButton("Permitir cambiar el brillo", Settings.ACTION_MANAGE_WRITE_SETTINGS))
        if (needOverlay) permBox.addView(permButton("Permitir mostrar sobre otras apps", Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
    }

    private fun permButton(t: String, action: String) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.parseColor("#1A1026"))
        background = GradientDrawable().apply { setColor(amber); cornerRadius = dp(14).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }
        setOnClickListener { startActivity(Intent(action, Uri.parse("package:$packageName"))) }
    }

    private fun showLevel(v: Int) {
        percent.text = "${v * 100 / 255}%"
        sunImg.alpha = 0.35f + 0.65f * v / 255f
        sunImg.scaleX = 0.8f + 0.2f * v / 255f; sunImg.scaleY = sunImg.scaleX
    }

    private fun setBrightness(v: Int) {
        if (!Settings.System.canWrite(this)) { refresh(); Toast.makeText(this, "Da permiso para cambiar el brillo", Toast.LENGTH_SHORT).show(); return }
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v.coerceAtLeast(1))
        window.attributes = window.attributes.apply { screenBrightness = v.coerceAtLeast(1) / 255f }
    }

    private fun setFloating(on: Boolean) {
        val i = Intent(this, FloatingService::class.java)
        if (on) {
            if (!Settings.canDrawOverlays(this) || !Settings.System.canWrite(this)) {
                toggle.isChecked = false
                Toast.makeText(this, "Primero concede los permisos de abajo", Toast.LENGTH_SHORT).show(); refresh(); return
            }
            startForegroundService(i)
        } else stopService(i)
    }
}
