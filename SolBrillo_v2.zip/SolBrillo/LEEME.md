# Sol Brillo
Sol flotante y semitransparente que puedes arrastrar. Al tocarlo se abre un deslizador para el brillo.

## Conseguir la APK sin instalar nada (GitHub)
1. Crea una cuenta en github.com y un repositorio nuevo.
2. "Add file" > "Upload files" y sube TODO el contenido de esta carpeta (incluida .github).
3. Pestaña "Actions": espera ~5 min a que termine "Construir APK" (check verde).
4. Entra en la ejecución y descarga "SolBrillo-apk" (zip con app-debug.apk).
5. Pásala al móvil, ábrela y permite "instalar apps desconocidas".

## Alternativa: Android Studio
Abre la carpeta > Build > Build APK(s).

## Al abrir la app
Concede los permisos que aparecen abajo y activa "Botón flotante".
